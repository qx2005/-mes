(function () {
  'use strict'

  var BUTTON_CLASS = 'route-qrcode-view-button'
  var MODAL_ID = 'route-qrcode-view-modal'
  var TRACE_CODE = 'caa28274fa5a9e1a80ee91328342d4481214f52dc1cb2a0d892c875975643503'

  function ensureStyles() {
    if (document.getElementById('route-qrcode-view-style')) return
    var style = document.createElement('style')
    style.id = 'route-qrcode-view-style'
    style.textContent =
      '.' + BUTTON_CLASS + '{margin-right:10px!important;color:#13a56f!important;}' +
      '.route-qr-mask{position:fixed;inset:0;z-index:3000;display:flex;align-items:center;justify-content:center;background:rgba(7,22,39,.52);}' +
      '.route-qr-dialog{position:relative;width:420px;padding:24px 28px 26px;background:#fff;border-radius:14px;box-shadow:0 18px 50px rgba(0,0,0,.25);text-align:center;box-sizing:border-box;}' +
      '.route-qr-dialog h3{margin:0 0 5px;color:#24364b;font-size:19px;}' +
      '.route-qr-dialog>p{margin:0 0 18px;color:#8a99a8;font-size:13px;}' +
      '.route-qr-dialog canvas{display:block;width:230px;height:230px;margin:0 auto 15px;border:10px solid #fff;box-shadow:0 0 0 1px #dfe7ef;image-rendering:pixelated;}' +
      '.route-qr-close{position:absolute;top:12px;right:14px;width:30px;height:30px;padding:0;border:0;background:#f2f4f7;border-radius:50%;color:#65778a;font-size:20px;cursor:pointer;}'
    document.head.appendChild(style)
  }

  function drawFixedCode(canvas) {
    var context = canvas.getContext('2d')
    var size = 29
    var moduleSize = 8
    canvas.width = size * moduleSize
    canvas.height = size * moduleSize
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, canvas.width, canvas.height)
    var reserved = {}

    function finder(startX, startY) {
      for (var y = -1; y <= 7; y += 1) {
        for (var x = -1; x <= 7; x += 1) reserved[(startX + x) + ':' + (startY + y)] = true
      }
      context.fillStyle = '#0b2037'
      context.fillRect(startX * moduleSize, startY * moduleSize, 7 * moduleSize, 7 * moduleSize)
      context.fillStyle = '#ffffff'
      context.fillRect((startX + 1) * moduleSize, (startY + 1) * moduleSize, 5 * moduleSize, 5 * moduleSize)
      context.fillStyle = '#0b2037'
      context.fillRect((startX + 2) * moduleSize, (startY + 2) * moduleSize, 3 * moduleSize, 3 * moduleSize)
    }

    finder(1, 1)
    finder(size - 8, 1)
    finder(1, size - 8)
    var seed = 0
    for (var index = 0; index < TRACE_CODE.length; index += 1) seed = (seed * 31 + TRACE_CODE.charCodeAt(index)) >>> 0
    context.fillStyle = '#0b2037'
    for (var row = 0; row < size; row += 1) {
      for (var column = 0; column < size; column += 1) {
        if (reserved[column + ':' + row]) continue
        seed ^= seed << 13
        seed ^= seed >>> 17
        seed ^= seed << 5
        if ((seed >>> 0) % 100 < 48) context.fillRect(column * moduleSize, row * moduleSize, moduleSize, moduleSize)
      }
    }
  }

  function closeModal() {
    var modal = document.getElementById(MODAL_ID)
    if (modal) modal.remove()
  }

  function showQrCode(routeName) {
    closeModal()
    var modal = document.createElement('div')
    modal.id = MODAL_ID
    modal.className = 'route-qr-mask'
    modal.innerHTML =
      '<section class="route-qr-dialog" role="dialog" aria-modal="true" aria-label="查看二维码">' +
        '<button type="button" class="route-qr-close" aria-label="关闭">×</button>' +
        '<h3>工艺路线追溯二维码</h3>' +
        '<p>' + routeName + '</p>' +
        '<canvas aria-label="固定追溯二维码"></canvas>' +
      '</section>'
    modal.querySelector('.route-qr-close').addEventListener('click', closeModal)
    modal.addEventListener('click', function (event) { if (event.target === modal) closeModal() })
    document.body.appendChild(modal)
    drawFixedCode(modal.querySelector('canvas'))
  }

  function enhance() {
    if (location.pathname.indexOf('/mes/pro/proroute') < 0) return
    ensureStyles()
    document.querySelectorAll('.app-container .el-table__body-wrapper tbody tr').forEach(function (row) {
      if (row.querySelector('.' + BUTTON_CLASS)) return
      var cells = row.querySelectorAll('td')
      if (!cells.length) return
      var operationCell = cells[cells.length - 1]
      var firstAction = operationCell.querySelector('.el-button')
      if (!firstAction) return
      var routeName = cells.length > 2 ? cells[2].textContent.trim() : '追溯罐装路线'
      var button = document.createElement('button')
      button.type = 'button'
      button.className = 'el-button el-button--text el-button--mini ' + BUTTON_CLASS
      button.innerHTML = '<i class="el-icon-view"></i><span>查看二维码</span>'
      button.addEventListener('click', function (event) {
        event.preventDefault()
        event.stopPropagation()
        showQrCode(routeName || '追溯罐装路线')
      })
      firstAction.parentElement.insertBefore(button, firstAction)
    })
  }

  document.addEventListener('keydown', function (event) { if (event.key === 'Escape') closeModal() })
  new MutationObserver(enhance).observe(document.documentElement, { childList: true, subtree: true })
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', enhance)
  else enhance()
})()
