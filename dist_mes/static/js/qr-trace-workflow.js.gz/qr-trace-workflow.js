(function () {
  'use strict'

  var PANEL_ID = 'qr-trace-workflow'
  var TRACE_CODE = 'caa28274fa5a9e1a80ee91328342d4481214f52dc1cb2a0d892c875975643503'
  var TRACE_STEPS = [
    { time: '02:47:53', title: '加密赋码建档', state: '已完成', detail: '生成产品唯一二维码身份码，并建立麦香拉格 4.5度产品档案。' },
    { time: '02:48:06', title: '生产批次绑定', state: '已完成', detail: '绑定 LINE-001、生产一组和批次 LOT-20260902-001。' },
    { time: '02:49:18', title: '罐装质检关联', state: '已完成', detail: '关联罐装液位、压盖密封及外观质检结果，质检状态合格。' },
    { time: '02:49:53', title: '产线扫码核验', state: '已通过', detail: 'CAMERA-001 完成扫码，身份码、产品和生产批次核验一致。' },
    { time: '待执行', title: '入库追溯确认', state: '待入库', detail: '入库时再次扫描二维码，确认仓库、库位和库存流水。' }
  ]

  function findRouteContainer() {
    var containers = Array.prototype.slice.call(document.querySelectorAll('.app-container'))
    return containers.find(function (container) {
      var text = container.textContent || ''
      return text.indexOf('工艺路线编号') >= 0 && text.indexOf('工艺路线名称') >= 0
    })
  }

  function drawTraceCode(canvas) {
    var context = canvas.getContext('2d')
    var size = 29
    var moduleSize = 6
    canvas.width = size * moduleSize
    canvas.height = size * moduleSize
    context.fillStyle = '#ffffff'
    context.fillRect(0, 0, canvas.width, canvas.height)
    var reserved = {}
    function finder(startX, startY) {
      for (var y = -1; y <= 7; y++) {
        for (var x = -1; x <= 7; x++) reserved[(startX + x) + ':' + (startY + y)] = true
      }
      context.fillStyle = '#0b2037'
      context.fillRect(startX * moduleSize, startY * moduleSize, 7 * moduleSize, 7 * moduleSize)
      context.fillStyle = '#ffffff'
      context.fillRect((startX + 1) * moduleSize, (startY + 1) * moduleSize, 5 * moduleSize, 5 * moduleSize)
      context.fillStyle = '#0b2037'
      context.fillRect((startX + 2) * moduleSize, (startY + 2) * moduleSize, 3 * moduleSize, 3 * moduleSize)
    }
    finder(1, 1)
    finder(size - 8, 1)
    finder(1, size - 8)
    var seed = 0
    for (var index = 0; index < TRACE_CODE.length; index++) seed = (seed * 31 + TRACE_CODE.charCodeAt(index)) >>> 0
    context.fillStyle = '#0b2037'
    for (var row = 0; row < size; row++) {
      for (var column = 0; column < size; column++) {
        if (reserved[column + ':' + row]) continue
        seed ^= seed << 13
        seed ^= seed >>> 17
        seed ^= seed << 5
        if ((seed >>> 0) % 100 < 48) context.fillRect(column * moduleSize, row * moduleSize, moduleSize, moduleSize)
      }
    }
  }

  function createPanel() {
    var panel = document.createElement('section')
    panel.id = PANEL_ID
    panel.className = 'qr-trace-workflow'
    panel.innerHTML =
      '<header class="trace-hero">' +
        '<div><span class="trace-kicker">QR TRACEABILITY WORKFLOW</span><h2>二维码全流程追溯中心</h2><p>以单品二维码为主线，贯通赋码、生产、质检、扫码与入库业务节点</p></div>' +
        '<div class="trace-hero-actions"><span class="trace-online"><i></i>追溯链路在线</span><button type="button" data-action="verify">核验追溯链</button></div>' +
      '</header>' +
      '<div class="trace-metrics">' +
        '<article><span>追溯对象</span><strong>麦香拉格 4.5度</strong><em>500ml×6罐</em></article>' +
        '<article><span>生产批号</span><strong>LOT-20260902-001</strong><em>2026-09-02</em></article>' +
        '<article><span>产线绑定</span><strong>LINE-001 · 产线一</strong><em>生产一组 / 生产车间</em></article>' +
        '<article><span>链路完整度</span><strong data-integrity>5 / 5</strong><em data-integrity-state>关键节点已关联</em></article>' +
      '</div>' +
      '<div class="trace-main">' +
        '<article class="trace-identity-card">' +
          '<div class="trace-card-title"><div><span>单品啤酒身份凭证</span><strong>加密二维码档案</strong></div><b>唯一身份</b></div>' +
          '<div class="trace-code-wrap"><canvas data-trace-code></canvas><div><span>二维码身份码</span><code>' + TRACE_CODE + '</code><button type="button" data-action="copy">复制身份码</button></div></div>' +
          '<div class="trace-identity-tags"><span>拉格型 / 4.5度</span><span>待入库</span><span>质检合格</span></div>' +
        '</article>' +
        '<article class="trace-profile-card">' +
          '<div class="trace-card-title"><div><span>生产身份绑定</span><strong>产品与生产档案</strong></div><b>已上链</b></div>' +
          '<dl class="trace-profile-grid">' +
            '<div><dt>产品名称</dt><dd>麦香拉格 4.5度</dd></div><div><dt>产品规格</dt><dd>500ml×6罐</dd></div>' +
            '<div><dt>生产批号</dt><dd>LOT-20260902-001</dd></div><div><dt>生产日期</dt><dd>2026-09-02</dd></div>' +
            '<div><dt>生产产线</dt><dd>产线一 / LINE-001</dd></div><div><dt>班组</dt><dd>生产一组</dd></div>' +
            '<div><dt>生成时间</dt><dd>02:47:53</dd></div><div><dt>最后流转</dt><dd>02:49:53</dd></div>' +
          '</dl>' +
          '<div class="trace-scan-result"><i class="el-icon-circle-check"></i><div><strong>CAMERA-001 扫码核验成功</strong><span>身份码、产品、产线与批次信息一致</span></div><em>已通过</em></div>' +
        '</article>' +
      '</div>' +
      '<article class="trace-flow-card">' +
        '<div class="trace-card-title"><div><span>全链路流转轨迹</span><strong>二维码追溯流程</strong></div><button type="button" data-action="config">查看底层工艺配置</button></div>' +
        '<div class="trace-flow" data-flow></div>' +
        '<div class="trace-step-detail" data-step-detail></div>' +
      '</article>' +
      '<div class="trace-toast" data-toast></div>'
    return panel
  }

  function renderSteps(panel) {
    var flow = panel.querySelector('[data-flow]')
    TRACE_STEPS.forEach(function (step, index) {
      var button = document.createElement('button')
      button.type = 'button'
      button.className = 'trace-flow-step' + (index === 0 ? ' active' : '') + (index === TRACE_STEPS.length - 1 ? ' pending' : '')
      button.innerHTML = '<span class="trace-step-index">0' + (index + 1) + '</span><div><time>' + step.time + '</time><strong>' + step.title + '</strong><em>' + step.state + '</em></div>'
      button.addEventListener('click', function () {
        flow.querySelectorAll('.trace-flow-step').forEach(function (item) { item.classList.remove('active') })
        button.classList.add('active')
        showStepDetail(panel, index)
      })
      flow.appendChild(button)
    })
    showStepDetail(panel, 0)
  }

  function showStepDetail(panel, index) {
    var step = TRACE_STEPS[index]
    panel.querySelector('[data-step-detail]').innerHTML = '<span>节点详情</span><strong>' + step.title + '</strong><p>' + step.detail + '</p><em>' + step.state + '</em>'
  }

  function showToast(panel, text) {
    var toast = panel.querySelector('[data-toast]')
    toast.textContent = text
    toast.classList.add('show')
    window.setTimeout(function () { toast.classList.remove('show') }, 1800)
  }

  function bindActions(panel, container) {
    panel.querySelector('[data-action="copy"]').addEventListener('click', function () {
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(TRACE_CODE)
      showToast(panel, '二维码身份码已复制')
    })
    panel.querySelector('[data-action="verify"]').addEventListener('click', function (event) {
      var button = event.currentTarget
      if (button.classList.contains('verifying')) return
      button.classList.add('verifying')
      button.textContent = '正在核验 0%'
      var progress = 0
      var timer = window.setInterval(function () {
        progress += 20
        button.textContent = progress < 100 ? '正在核验 ' + progress + '%' : '✓ 链路核验通过'
        if (progress >= 100) {
          window.clearInterval(timer)
          button.classList.remove('verifying')
          button.classList.add('verified')
          panel.querySelector('[data-integrity]').textContent = '5 / 5'
          panel.querySelector('[data-integrity-state]').textContent = '数据一致 · 链路完整'
          showToast(panel, '5 个关键追溯节点核验通过')
        }
      }, 180)
    })
    panel.querySelector('[data-action="config"]').addEventListener('click', function (event) {
      var visible = container.classList.toggle('show-native-route-config')
      event.currentTarget.textContent = visible ? '收起底层工艺配置' : '查看底层工艺配置'
      if (visible) container.lastElementChild.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
  }

  function enhance() {
    var container = findRouteContainer()
    if (!container || container.querySelector('#' + PANEL_ID)) return
    Array.prototype.slice.call(container.children).forEach(function (child) { child.classList.add('native-route-config') })
    var panel = createPanel()
    container.insertBefore(panel, container.firstChild)
    container.classList.add('qr-trace-page')
    drawTraceCode(panel.querySelector('[data-trace-code]'))
    renderSteps(panel)
    bindActions(panel, container)
  }

  new MutationObserver(enhance).observe(document.documentElement, { childList: true, subtree: true })
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', enhance)
  else enhance()
})()
